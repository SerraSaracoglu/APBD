﻿using exam.Models;
using Lab_09.DTOs;
using Lab_09.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace exam.Controllers
{
    [Route("api/artists")]
    [ApiController]
    public class ArtistsConroller : ControllerBase
    {
        private readonly IArtistDbService _service;

        public ArtistsConroller(IArtistDbService service)
        {
            _service = service;
        }

        [HttpPost]
        public IActionResult AddArtist(AddArtistRequest request) 
        {
            _service.AddArtist(request);

            var response = new AddArtistResponse();

            return Ok(response);
        }
    }
}
