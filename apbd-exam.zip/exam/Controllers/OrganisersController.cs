﻿using exam.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace exam.Controllers
{
    [Route("api/organisers")]
    [ApiController]
    public class OrganisersController : ControllerBase
    {

        private readonly s19188Context _context;

        public OrganisersController(s19188Context context) 
        {
            _context = context;
        }

        [HttpGet("{id}")]
        public IActionResult GetOrganiser(int id) 
        {
            var org = _context.Organisers.Where(o => o.IdOrganiser.Equals(id)).FirstOrDefault();

            if (org == null) 
            {
                Console.WriteLine("this organiser do not exists");
            }

            var evorg = _context.EventOrganisers.Where(e => e.IdOrganiser.Equals(org.IdOrganiser)).ToList();

            List<Event> eventsList = new List<Event>();

            foreach (EventOrganiser e in evorg) 
            {
                var eventId = e.IdEvent;
                var events = _context.Events.Where(e => e.IdEvent == eventId).FirstOrDefault();

                eventsList.Add(events);
                
            } 

            return Ok(org + "and their events"+  eventsList);
        }

    }
}
