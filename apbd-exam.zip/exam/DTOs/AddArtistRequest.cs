﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Lab_09.DTOs
{
    public class AddArtistRequest
    {
        [Required] 
        public string Nickname { get; set; }
            
        public string EventName { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

    }
}
