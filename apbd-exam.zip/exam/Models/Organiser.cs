﻿using System;
using System.Collections.Generic;

#nullable disable

namespace exam.Models
{
    public partial class Organiser
    {
        public Organiser()
        {
            EventOrganisers = new HashSet<EventOrganiser>();
        }

        public int IdOrganiser { get; set; }
        public string Name { get; set; }

        public virtual ICollection<EventOrganiser> EventOrganisers { get; set; }
    }
}
