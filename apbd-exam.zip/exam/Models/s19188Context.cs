﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace exam.Models
{
    public partial class s19188Context : DbContext
    {
        public s19188Context()
        {
        }

        public s19188Context(DbContextOptions<s19188Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Artist> Artists { get; set; }
        public virtual DbSet<ArtistEvent> ArtistEvents { get; set; }
        public virtual DbSet<Event> Events { get; set; }
        public virtual DbSet<EventOrganiser> EventOrganisers { get; set; }
        public virtual DbSet<Organiser> Organisers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=db-mssql;Initial Catalog=s19188;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Polish_CI_AS");

            modelBuilder.Entity<Artist>(entity =>
            {
                entity.HasKey(e => e.IdArtist)
                    .HasName("Artist_pk");

                entity.ToTable("Artist");

                entity.Property(e => e.IdArtist).ValueGeneratedNever();

                entity.Property(e => e.Nickname)
                    .IsRequired()
                    .HasMaxLength(30);
            });

            modelBuilder.Entity<ArtistEvent>(entity =>
            {
                entity.HasKey(e => e.IdArtistEvent)
                    .HasName("Artist_Event_pk");

                entity.ToTable("Artist_Event");

                entity.Property(e => e.IdArtistEvent).ValueGeneratedNever();

                entity.Property(e => e.PerformanceDate).HasColumnType("datetime");

                entity.HasOne(d => d.IdArtistNavigation)
                    .WithMany(p => p.ArtistEvents)
                    .HasForeignKey(d => d.IdArtist)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("Artist_Event_Artist");

                entity.HasOne(d => d.IdEventNavigation)
                    .WithMany(p => p.ArtistEvents)
                    .HasForeignKey(d => d.IdEvent)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("Artist_Event_Event");
            });

            modelBuilder.Entity<Event>(entity =>
            {
                entity.HasKey(e => e.IdEvent)
                    .HasName("Event_pk");

                entity.ToTable("Event");

                entity.Property(e => e.IdEvent).ValueGeneratedNever();

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.StartDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<EventOrganiser>(entity =>
            {
                entity.HasKey(e => e.IdEventOrganiser)
                    .HasName("Event_Organiser_pk");

                entity.ToTable("Event_Organiser");

                entity.Property(e => e.IdEventOrganiser).ValueGeneratedNever();

                entity.HasOne(d => d.IdEventNavigation)
                    .WithMany(p => p.EventOrganisers)
                    .HasForeignKey(d => d.IdEvent)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("Table_4_Event");

                entity.HasOne(d => d.IdOrganiserNavigation)
                    .WithMany(p => p.EventOrganisers)
                    .HasForeignKey(d => d.IdOrganiser)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("Table_4_Organiser");
            });

            modelBuilder.Entity<Organiser>(entity =>
            {
                entity.HasKey(e => e.IdOrganiser)
                    .HasName("Organiser_pk");

                entity.ToTable("Organiser");

                entity.Property(e => e.IdOrganiser).ValueGeneratedNever();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(30);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
