﻿using exam.Models;
using Lab_09.DTOs;
using System;
using System.Linq;

namespace Lab_09.Services
{
    public class SqlArtistService : IArtistDbService
    {

        private readonly s19188Context _context;
        public SqlArtistService(s19188Context context)
        {
            _context = context;
        }

        public void AddArtist(AddArtistRequest request)
        {
            var artist = _context.Artists.Where(a => a.Nickname.Equals(request.Nickname)).FirstOrDefault();

            if (artist != null)
            {
                Console.WriteLine("artist already exists");
            }

            var newArtist = new Artist
            {
                Nickname = request.Nickname
            };

            _context.Add(newArtist);


            //start date not in the past 
            var startDate = request.StartDate;

            if (startDate < DateTime.Now)
            {
                Console.WriteLine("start date can't be in the past");
            }

            //artist not assigned to this event already 
            //no pair id artist and id event ==> artist event id is null 
            //id of artist 
            //id of event

            var artistId = newArtist.IdArtist;
            var eventId = _context.Events.Where(e => e.Name.Equals(request.EventName) && e.StartDate.Equals(request.StartDate)).FirstOrDefault().IdEvent;

            var artistEvent = _context.ArtistEvents.Where(e => e.IdEvent == eventId && e.IdArtist == artistId).FirstOrDefault();

            if (artistEvent != null) 
            {
                Console.WriteLine("this artist is already assigned to this event");
            }

            var newAssignToEvent = new ArtistEvent
            {
                IdArtist = artistId,
                IdArtistEvent = eventId
            };

            _context.SaveChanges();
        }

    }
}
