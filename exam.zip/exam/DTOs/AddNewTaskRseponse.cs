﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab_09.DTOs
{
    public class AddNewTaskResponse

    {
        public string Name { get; set; }
       
    }
}
